# Akbank Derin Öğrenme Bootcamp - CNN Görüntü Sınıflandırma Projesi

## Projenin Amacı
Bu projede, CNN tabanlı bir derin öğrenme modeli kullanarak seçilen veri seti üzerinde görüntü sınıflandırması gerçekleştirilmektedir.

## Veri Seti Hakkında
- **Veri Seti:** Intel Image Classification  
- **Sınıflar:** Buildings, Forest, Glacier, Mountain, Sea, Street  
- **Boyut:** ~25.000 eğitim, 14.000 test görüntüsü  
- [Kaggle Linki](https://www.kaggle.com/datasets/puneet6060/intel-image-classification)

## Kullanılan Yöntemler
- CNN, Data Augmentation, Confusion Matrix, Grad-CAM

## Kaggle Notebook Linki
- [CNN Image Classification Notebook](KAGGLE_NOTEBOOK_LINK)
